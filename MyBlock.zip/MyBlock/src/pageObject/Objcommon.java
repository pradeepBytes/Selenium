package pageObject;

import org.openqa.selenium.By;

public class Objcommon {

	public static By Zsclr_clicklink = By.linkText("Click here");
	public static By Zsclr_accptButtn = By.name("button");
}

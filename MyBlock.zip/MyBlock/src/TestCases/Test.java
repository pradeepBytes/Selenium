package TestCases;

import java.io.IOException;

import utility.Constant_Class;

public class Test {

	
	public static void main(String[] args) throws IOException {
		
		
		Runtime.getRuntime().exec("wscript" + " "+ System.getProperty("user.dir") + "\\resources\\script.vbs");
	}
}

package TestCases;

import com.ustglobal.common.BatchRunner;

public class BatchRun {

	public static void main(String[] args) {
		BatchRunner.Launch();
}
}

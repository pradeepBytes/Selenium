package business_actions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import com.ustglobal.selenium.SInteractive;

import pageObject.Objcommon;
import utility.Constant_Class;

public class MyblockActions extends SInteractive {
	
	public ExcelAction actExcel;
	public LoginAction actLogin;
	public CreateNewAccount actCtracnt;
	public UploadDocAction actUplddoc;
	public CardIdentityAction actCardIdnty;
	public LogoutAction actLogout;
	public EmerlandcardAction actEmrldCard;
	

	public MyblockActions(String[] args) throws Exception {
		super(args);
		// TODO Auto-generated constructor stub
		actExcel = new ExcelAction();
		actLogin = new LoginAction(this);
		actCtracnt = new CreateNewAccount(this);
		actUplddoc = new UploadDocAction(this);
		actCardIdnty = new CardIdentityAction(this);
		actLogout = new LogoutAction(this);
		actEmrldCard = new EmerlandcardAction(this);
		}
	
	public void NavigateToURL() throws Exception{
		try {
			 
			  Navigate(Constant_Class.URL);
			  MaximizeBrowser();
			  boolean element = ElementExists(Objcommon.Zsclr_clicklink);
			  if(element){
				  	Element(Objcommon.Zsclr_clicklink).click();
					WaitForPageLoad();
					Element(Objcommon.Zsclr_accptButtn).click();
					WaitForPageLoad();
			  }
			  
			  else{
				  System.out.println("page is loaded directly");
			  }
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		
	
	public void NavigateToSSDURL() throws Exception{
		try {
			  
			  Navigate(Constant_Class.URL1);
			  boolean element = ElementExists(Objcommon.Zsclr_clicklink);
			  if(element){
				  	Element(Objcommon.Zsclr_clicklink).click();
					WaitForPageLoad();
					Element(Objcommon.Zsclr_accptButtn).click();
					WaitForPageLoad();
			  }
			  
			  else{
				  System.out.println("page is loaded directly");
			  }
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	
	}

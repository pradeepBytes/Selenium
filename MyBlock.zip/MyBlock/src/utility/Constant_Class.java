package utility;

public class Constant_Class {

	 public static final String URL = "https://myaccountqa.hrblock.net/mytax/";
	 
     public static final String Username = "winner1717";

     public static final String Password = "Welcome@1";
     
     public static final String txt_wlcm = "Welcome,";
     
     public static final String txt_filing = "FILING DONE, TAXES WON.";
     public static String Testcase_name = "";
     
     
     public static final String txt_msg = "Get a head start on next year -- upload your 2017 tax docs as you get them!";
     
     public static final String Path_TestData = System.getProperty("user.dir")+"/resources/TestData.xlsx";
     public static final String doc_uplScript="wscript" + " "+ System.getProperty("user.dir") + "\\resources\\script.vbs";
     public static final String doc_upldfile1 = "D://Ktb//Desert.jpg";
     
     public static final String URL1 = "http://devguaweb01.hrbinc.hrblock.net:8080/examples/QAADMINTOOL.jsp"; 
     
}


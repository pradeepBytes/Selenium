package utility;

public class Config {

	public String[] GetConfig(){
		String[] sConf={"chrome"};
		return sConf;
	}
}
